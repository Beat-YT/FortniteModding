http://sf5.tech

----------------------------
Convert mod folders to .paks
----------------------------

1) Drag and drop your mod folder onto DROP_MOD_FOLDER_HERE.bat file

2) Follow the instructions on screen

3) Find your .pak file in the "pak" directory

------------
To use .paks
------------

1) Create a directory named "~mods" in:
   \steamapps\common\StreetFighterV\StreetFighterV\Content\Paks\

2) Add desired .pak files to the "~mods" directory you created

3) Launch game

---------------
To unpack .paks
---------------

1) Drop your .pak file onto UNPACK.bat

2) Follow the instructions on screen

3) Find your mod folder in the "unpak" directory

-------
Credits
-------

- Panzi (u4pak - https://github.com/panzi/u4pak) 



